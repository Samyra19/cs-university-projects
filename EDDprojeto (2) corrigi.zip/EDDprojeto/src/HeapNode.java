public class HeapNode {
    Paciente paciente;
    HeapNode left;
    HeapNode right;

    public HeapNode(Paciente paciente){
        this.paciente = paciente;
    }
}
